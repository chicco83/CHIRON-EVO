The Builds in this folder have different options set for use 
if you have replaced the stepper drivers in your printer.

PLEASE NOTE: These builds are are based on the same code and the main firmware                      release, but the actual configurations have not been tested.

Chiron_2.0.7_TMC2208_Standalone.hex
  All stepper drivers set to TMC2208_STANDALONE

Chiron_2.0.7_TMC2208_Standalone_Reversed.hex
  All stepper drivers set to TMC2208_STANDALONE
  Stepper directions are all inverted.

Chiron_2.0.7_TMC2209_Standalone.hex
  All stepper drivers set to TMC2209_STANDALONE

Chiron_2.0.7_TMC2209_Standalone_Reversed.hex
  All stepper drivers set to TMC2209_STANDALONE
  Stepper directions are all inverted.
