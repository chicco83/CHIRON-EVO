# ANYCUBIC_CHIRON_V1.3.0
CHIRON_V1.3.0

For figure out unexpected halt:

>Added Mintemphotend filtering. 

>Added Err info.

Shows on TFT's INFO, if no error, will show firmware version. 
