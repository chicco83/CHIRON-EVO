#version 110

uniform vec4 uniform_color;

void main()
{
    gl_FragColor = uniform_color;
}
